
<form action="<?php echo e(route('profile.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="name" class="form-label">ชื่อ</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>
    </div>
    <div class="mb-3">
        <label for="phon" class="form-label">เบอร์โทร</label>
        <input type="text" class="form-control" id="phon" name="phon" value="<?php echo e(old('phon', $user->phon)); ?>" required>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">อีเมล</label>
        <input type="email" class="form-control" id="email" value="<?php echo e($user->email); ?>" disabled>
    </div>

    <button type="submit" class="btn btn-primary">บันทึก</button>
</form>


<?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/edit_profile.blade.php ENDPATH**/ ?>