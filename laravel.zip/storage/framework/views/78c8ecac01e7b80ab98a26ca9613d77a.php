<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/adminstyle.css">
</head>
<body>
<main class="d-flex flex-nowrap">
   <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="p-3 container-fluid">
        <div class="p-2 mb-1 bg-light rounded-3">
            <center><h5 class="fw-bold">เพิ่มโปรโมชัน</h5></center>
        </div>
        <section class="w-100 p-4 d-flex justify-content-center pb-4">

            <form class="needs-validation" action="<?php echo e(route('promotions.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-sm-6">
                        <label for="promotion_name" class="form-label">ชื่อโปรโมชัน</label>
                        <input type="text" class="form-control" name="promotion_name" required>
                    </div>
                    <div class="col-sm-6">
                        <label for="" class="form-label">ส่วนลด</label>
                        <div class="d-flex align-items-center">
                            <input type="number" class="form-control me-2 flex-grow-1" name="discount_value" required>
                            <select class="form-control flex-shrink-0"  name="discount_type" required style="width: auto;">
                                <option value="percentage">%</option>
                                <option value="fixed">บาท</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <label for="start_time" class="form-label">เริ่ม</label>
                        <input type="date" class="form-control" name="start_time" required>
                    </div>
                    <div class="col-sm-6">
                        <label for="end_time" class="form-label">สิ้นสุด</label>
                        <input type="date" class="form-control" name="end_time" required>
                    </div>
                </div>
                <hr class="my-4">
                <button class="btn btn-primary btn-lg w-50 d-block mx-auto" type="submit">บันทึก</button>
            </form>

        </section>

        <div class="p-5 mb-4 bg-light rounded-3">
            <div class="container-fluid py-1">
                <h4 class="fw-bold">รายการโปรโมชัน</h4>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            
                            <th scope="col">ชื่อโปรโมชัน</th>
                            <th scope="col">ส่วนลด</th>
                            <th scope="col">เริ่ม</th>
                            <th scope="col">สิ้นสุด</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>    
                                <td> <?php echo e($promotion->promotion_name); ?> </td>
                                <td>    <?php if($promotion->discount_type == 'percentage'): ?>
                                            <?php echo e($promotion->discount_value); ?>%
                                        <?php else: ?>
                                            <?php echo e($promotion->discount_value); ?> บาท
                                        <?php endif; ?>
                                </td>
                                <td><?php echo e($promotion->start_time->format('Y-m-d')); ?> </td>
                                <td><?php echo e($promotion->end_time ? $promotion->end_time->format('Y-m-d') : 'ไม่ระบุ'); ?></td>
                                <td>
                                    <a href="#" class="btn btn-warning editBtn" data-id="" data-bs-toggle="modal" data-bs-target="#editModal">แก้ไข</a>
                                    <a href="" class="btn btn-danger">ลบ</a> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>    
    </div>
</main>







<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views//add_promotion.blade.php ENDPATH**/ ?>