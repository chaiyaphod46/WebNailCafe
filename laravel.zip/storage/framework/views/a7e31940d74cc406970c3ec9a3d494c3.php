<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NailCafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminstyle.css">
</head>
<body>
    
<div class="container">
        <div class="reservation-detail">
            <p><strong>ชื่อ:</strong> <?php echo e($reservation->user->name); ?></p>
            <p><strong>เบอร์โทร:</strong> <?php echo e($reservation->user->phon); ?></p>
            <p><strong>วันที่:</strong> <?php echo e(\Carbon\Carbon::parse($reservation->reservs_start)->translatedFormat('j F Y')); ?></p>
            <p><strong>เวลา:</strong> <?php echo e(date('H:i', strtotime($reservation->reservs_start))); ?> ถึง <?php echo e(date('H:i', strtotime($reservation->reservs_end))); ?></p>
            
            
            <?php if($reservation->detailTimereservs->first() && $reservation->detailTimereservs->first()->nailDesign): ?>
                <div class="image-container">
                    <img src="<?php echo e(asset('naildesingimage/' . $reservation->detailTimereservs->first()->nailDesign->image)); ?>" width="100%" height="auto">
                </div>
            <?php else: ?>
                <p>ไม่มีลายเล็บ</p>
            <?php endif; ?>

            <p><strong>บริการเสริม:</strong></p>
            <?php if($reservation->detailTimereservs->isNotEmpty()): ?>
                <ul>
                    <?php $__currentLoopData = $reservation->detailTimereservs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->additionalServices): ?>
                            <li><?php echo e($detail->additionalServices->service_name); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p>ไม่มีบริการเสริม</p>
            <?php endif; ?>
            <p><strong>ราคารวม:</strong> <?php echo e($reservation->price); ?> บาท </p>
            <p><strong>โปรโมชั่น:</strong> <?php echo e($reservation->promotion ? $reservation->promotion->promotion_name : 'ไม่ใช้โปรโมชัน'); ?></p>
            <?php if($reservation->promotion): ?>
            <p><strong>ส่วนลด:</strong> 
                <?php if($reservation->promotion->discount_type == 'percentage'): ?>
                    <?php echo e(number_format($reservation->promotion->discount_value)); ?>%
                <?php elseif($reservation->promotion->discount_type == 'fixed'): ?>
                    <?php echo e(number_format($reservation->promotion->discount_value)); ?> บาท
                <?php else: ?>
                    ไม่ระบุประเภทส่วนลด
                <?php endif; ?>
            </p>
            <?php endif; ?>
            <p><strong>ราคารวมหลังใช้โปรโมชัน:</strong> <?php echo e($reservation->use_promotion_price); ?> บาท</p>
            <p><strong>สถานะ:</strong> 
                <span class="<?php echo e($reservation->statusdetail == 'รอชำระเงิน' ? 'text-warning' : 
                        (in_array($reservation->statusdetail, ['ชำระเงินมัดจำแล้ว', 'จองสำเร็จ']) ? 'text-success' : '')); ?>">
                        <?php echo e($reservation->statusdetail); ?>

                </span>
            </p>
            <div class="text-end mt-4 d-flex justify-content-end gap-2">


            <form action="<?php echo e(route('reservations.cancel', $reservation->reservs_id)); ?>" method="POST" onsubmit="return confirm('คุณต้องการยกเลิกการจองนี้หรือไม่?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">ยกเลิกการจอง</button>
            </form>
            <form action="<?php echo e(route('reservations.confirm', $reservation->reservs_id)); ?>" method="POST" onsubmit="return confirm('คุณต้องการยืนยันการจองนี้หรือไม่?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button type="submit" class="btn btn-success">ยืนยันการจอง</button>
            </form>
        </div>
            
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/reservationDetails.blade.php ENDPATH**/ ?>