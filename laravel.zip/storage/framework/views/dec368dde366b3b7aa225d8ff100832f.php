<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
    
</head>
<body>

    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12">
                <h2>Add Naildesign </h2>
            </div>
            <div>
                <a href="<?php echo e(route('design.index')); ?>" class="btn btn-primary"> Back</a>
            </div>
            <?php if(session('status')): ?>
               <div class="alert alert-success">
                 <?php echo e(session('status')); ?>

               </div>
            <?php endif; ?>
            <form action="<?php echo e(route('design.store')); ?>" method="POST" enctype="multipart/form-data">
                
                <div class="row">

                    <div class="col-md-12">
                        <div class="foem-group">
                            <strong>Nail Name </strong>
                            <input type="text" name="nailname" class="form-control">
                            <?php $__errorArgs = ['nailname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"> <?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="foem-group">
                            <strong>Nail image </strong>
                            <input type="file" name="image" class="form-control">
                            
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="mt-3 btn btn-primary" > Save</button>
                    </div>

                   
                </div> 
            </form>

        </div>


    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/design/create.blade.php ENDPATH**/ ?>