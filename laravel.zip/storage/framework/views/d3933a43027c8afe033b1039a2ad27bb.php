<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NailCafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


</head>
<body>

<div class="container mt-4">
    <main>
        <!-- Section for Promotion Details -->
        <div class="mb-2 text-center">
            <h3 class="fw-bold"><?php echo e($promotion->promotion_name); ?></h3>
            <p class="fs-5 text-muted">
                ลด 
                <?php if($promotion->discount_type == 'percentage'): ?>
                    <?php echo e(floor($promotion->discount_value)); ?>%
                <?php else: ?>
                    <?php echo e(floor($promotion->discount_value)); ?> บาท
                <?php endif; ?>
            </p>
            <p class="fs-6">โค้ดส่วนลด: <b><?php echo e($promotion->promotion_code); ?></b></p>
            <p class="fs-6">
                <b>ตั้งแต่:</b> <?php echo e(\Carbon\Carbon::parse($promotion->start_time)->translatedFormat('j F')); ?> 
                <b>ถึง:</b> <?php echo e($promotion->end_time ? \Carbon\Carbon::parse($promotion->end_time)->translatedFormat('j F Y') : 'ไม่ระบุ'); ?>

            </p>
            
        </div>
        <p class="fs-6 text-center"> ลายเล็บที่เข้าร่วมโปรโมชัน </p>
        <!-- Section for Nail Design Details -->
        <div class="row">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $promotion->detailPromotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm">
                                <img src="<?php echo e(asset('naildesingimage/' . $detail->nailDesign->image)); ?>" width="100%" height="225" class="bd-placeholder-img card-img-top">
                                <div class="card-body">
                                    <p class="card-text"><?php echo e($detail->nailDesign->nailname); ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" id="start-camera" class="btn btn-sm btn-outline-secondary me-2" style="width: 100px; font-size: 12px;">Virtual try-on</button>
                                            <form action="<?php echo e(route('reserv')); ?>" method="GET">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="nail_design_id" value="<?php echo e($detail->nailDesign->nail_design_id); ?>">
                                                <input type="hidden" name="nail_image" value="<?php echo e($detail->nailDesign->image); ?>">
                                                <input type="hidden" name="nail_name" value="<?php echo e($detail->nailDesign->nailname); ?>">
                                                <input type="hidden" name="nail_price" value="<?php echo e($detail->nailDesign->design_price); ?>">
                                                <input type="hidden" name="nail_time" value="<?php echo e($detail->nailDesign->design_time); ?>">
                                                <input type="hidden" name="promotion_code" value="<?php echo e($promotion->promotion_code); ?>">
                                                <button type="submit" class="btn btn-sm btn-dark" style="width: 100px; font-size: 12px;">จอง</button>
                                            </form>  
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </main>
</div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>  
</body>
</html><?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/showdetail_promotion.blade.php ENDPATH**/ ?>