<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>

    <div class="container mt-2">
        <div class= "row">
            <div class="col-lg-12 text-center">
                <h2>Naildesign</h2>
            </div>
            <div>
                <a href="<?php echo e(route('design.create')); ?>" class="btn btn-success"> Create Naildesign</a>
            </div>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>

            <table class="table table-bordered">
            <tr>
                    <th> ID </th>
                    <th> Nailname </th>
                    <th> Image </th>
                    <th width="280px"> Action</th>
                </tr>
                <?php $__currentLoopData = $naildesigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $naildesigns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($naildesigns->nail_design_id); ?></th>
                        <th><?php echo e($naildesigns->nailname); ?></th>
                        <th><?php echo e($naildesigns->image); ?></th>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
                

        </div>

    </div>
    







</body>
</html><?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/design/shownaildesigns.blade.php ENDPATH**/ ?>