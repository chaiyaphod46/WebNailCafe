
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>
<main class="d-flex flex-nowrap">
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="p-3 container-fluid">
      
      <?php $__env->startSection('content'); ?>
            <div class="container"> 
               <h1>  </h1>
               <div class="row center">

               <form action="<?php echo e(route('manage_time.update')); ?>" method="post">
                   <?php echo csrf_field(); ?>


                   <?php $__currentLoopData = $businessHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businessHour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                   <div class="col s3">
                <h2>  <?php echo e($businessHour->day); ?> </h2>
            </div>

            <input type="hidden" name="data[<?php echo e($businessHour->day); ?>][day]" value="<?php echo e($businessHour->day); ?>">
            <div class="input-field col s3">
                <input type="text" class="timepicker" value="<?php echo e($businessHour->form); ?>" name="data[<?php echo e($businessHour->day); ?>][form]" placeholder="From">
            </div>

            <div class="input-field col s2">
                <input type="text" class="timepicker" value="<?php echo e($businessHour->to); ?>" name="data[<?php echo e($businessHour->day); ?>][to]" placeholder="To">
            </div>

            <div class="input-field col s1">
                <input type="number" class="timepicker" value="<?php echo e($businessHour->step); ?>" name="data[<?php echo e($businessHour->day); ?>][step]" placeholder="Step">
            </div>

            <div class="input-field col s3">
                <p>
                    <label >
                        <input name="data[<?php echo e($businessHour->day); ?>][off]" class="filled-in" type="checkbox" <?php if($businessHour->off): echo 'checked'; endif; ?>/>
                         <span>OFF</span>
                    </label>
                </p>
            </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col s12">

                <button class="waves-effect waves-light btn info darken-2" type="submit"> save </button>

            </div>
                        
                   
                </form>
               </div>
            </div>


    </div>






</main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/manage_time.blade.php ENDPATH**/ ?>