<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NailCafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="icon" href="<?php echo e(asset('imag/nailcafe1.jpg')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" />

</head>
<body>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h5>การจองของฉัน</h5>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo e(request('filter') == 'history' ? 'ประวัติการจอง' : 'การจองปัจจุบัน'); ?>

                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <li><a class="dropdown-item" href="<?php echo e(route('showreservations', ['filter' => 'active'])); ?>">การจองปัจจุบัน</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('showreservations', ['filter' => 'history'])); ?>">ประวัติการจอง</a></li>
                </ul>
            </div>
        </div>
        
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-3 col-md-6 mb-3 d-flex">
                    <div class="card shadow-sm flex-fill" style="min-height: 100%;">
                        <?php if($reservation->detailTimereservs->first() && $reservation->detailTimereservs->first()->nailDesign): ?>
                            <img src="<?php echo e(asset('naildesingimage/' . $reservation->detailTimereservs->first()->nailDesign->image)); ?>" width="100%" height="220" class="bd-placeholder-img card-img-top">
                        <?php endif; ?>
                        <div class="card-body d-flex flex-column" style="line-height: 1.2;"> 
                            <h5><p class="card-text">วันที่จอง: <?php echo e(\Carbon\Carbon::parse($reservation->reservs_start)->translatedFormat('j F Y')); ?></p></h5>
                            <h5><p class="card-text">เวลาที่จอง: <?php echo e(date('H:i', strtotime($reservation->reservs_start))); ?> ถึง <?php echo e(date('H:i', strtotime($reservation->reservs_end))); ?></p></h5>

                            <p class="card-text 
                                <?php echo e($reservation->statusdetail == 'รอชำระเงินมัดจำ' ? 'text-warning' : 
                                ($reservation->statusdetail == 'ชำระเงินมัดจำแล้ว' || $reservation->statusdetail == 'จองสำเร็จ' ? 'text-success' : '')); ?>" 
                                id="status_<?php echo e($reservation->reservs_id); ?>">
                                <?php echo e($reservation->statusdetail); ?>

                            </p>

                            <?php if($reservation->detailTimereservs->isNotEmpty()): ?>
                                <p class="card-text">บริการเพิ่มเติม:</p>
                                <ul class="card-text">
                                    <?php $__currentLoopData = $reservation->detailTimereservs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($detail->additionalServices): ?>
                                            <li><?php echo e($detail->additionalServices->service_name); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                                <p class="card-text mt-auto"><strong>ราคารวม:</strong> <?php echo e(number_format($reservation->price)); ?> บาท </p>
                                <p class="card-text mt-auto"><strong>ใช้ code:</strong> <?php echo e($reservation->promotion ? $reservation->promotion->promotion_code : 'ไม่มี'); ?> </p>
                                <p class="card-text mt-auto"><strong>ราคาหลังลด:</strong> <?php echo e(number_format($reservation->use_promotion_price)); ?> บาท </p>

                                <?php if(request('filter') !== 'history'): ?>
                                
                                    <?php if($reservation->statusdetail == 'รอชำระเงินมัดจำ'): ?>
                                        <p class="text-warning fw-bold">กรุณาชำระเงินภายใน: <span id="countdown_<?php echo e($reservation->reservs_id); ?>"></span></p>
                                        <button class="btn btn-warning w-100 mb-2" id="paymentButton_<?php echo e($reservation->reservs_id); ?>" onclick="goToPayment(<?php echo e($reservation->reservs_id); ?>)">ชำระเงิน</button>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('showreservations.cancel', $reservation->reservs_id)); ?>" method="POST" onsubmit="return confirm('คุณต้องการยกเลิกการจองใช่หรือไม่?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger w-100">ยกเลิกการจอง</button>
                                    </form>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <p>ไม่พบการจอง</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</main>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    
    <script>
        // กลับไปจ่ายเงิน
        function goToPayment(reservs_id) {
            window.location.href = '/payment?reservs_id=' + reservs_id;
        }
    </script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    function startCountdown(reservs_id, expirationTime) {
        let countdownElement = document.getElementById(`countdown_${reservs_id}`);
        let paymentButton = document.getElementById(`paymentButton_${reservs_id}`);
        if (!countdownElement || !paymentButton) return;

        let interval = setInterval(() => {
            let now = new Date().getTime();
            let timeLeft = new Date(expirationTime).getTime() - now;

            if (timeLeft <= 0) {
                clearInterval(interval);
                countdownElement.innerText = "หมดเวลาชำระเงินแล้ว";
                paymentButton.style.display = "none"; // ซ่อนปุ่มชำระเงิน
                return;
            }

            let hours = Math.floor(timeLeft / 3600000);
            let minutes = Math.floor((timeLeft % 3600000) / 60000);
            let seconds = Math.floor((timeLeft % 60000) / 1000);
            countdownElement.innerText = `เวลาที่เหลือในการชำระเงินมัดจำ: ${hours} ชั่วโมง ${minutes} นาที ${seconds} วินาที`;
        }, 1000);
    }

    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($reservation->statusdetail == 'รอชำระเงินมัดจำ'): ?>
            startCountdown(<?php echo e($reservation->reservs_id); ?>, "<?php echo e($reservation->payment_expiration); ?>");
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
});
</script>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Nailcafe\resources\views/showreserv.blade.php ENDPATH**/ ?>