<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Timereservs;
use App\Models\User;
use App\Models\Payment;
use Carbon\Carbon;
use App\Models\UseCode;
use App\Models\Promotion;
use App\Models\DetailTimereserv; 

class DashboardController extends Controller
{
    public function index()
    {
         // ดึงจำนวนการจองทั้งหมดจากตาราง timereservs
         $totalReservations = Timereservs::withTrashed()->count(); // ใช้ withTrashed() เพื่อรวมรายการที่ถูกลบด้วย Soft Delete
         // ดึงรายการจองที่มีสถานะ "จองสำเร็จ"
        $successfulBookings = Timereservs::where('statusdetail', 'จองสำเร็จ')->count();

        // ดึงรายการที่ถูกยกเลิกการจองจากตาราง timereservs "
        $cancelledBookings = Timereservs::withTrashed()
        ->whereIn('statusdetail', ['ยกเลิกการจอง', 'หมดเวลาชำระเงิน', 'ยกเลิกการจองจากผู้ใช้'])
        ->count(); // ใช้ count() เพื่อหาจำนวนรายการที่ยกเลิก
        
        $expiredPayments = Timereservs::withTrashed()
    ->where('statusdetail', 'หมดเวลาชำระเงิน')
    ->count();

        $ownerCancelledBookings = Timereservs::withTrashed()
        ->where('statusdetail', 'ยกเลิกการจอง')
        ->count();

         // ดึงข้อมูลลูกค้าที่ไม่ใช่แอดมิน และคำนวณจำนวนการจองสำเร็จและการยกเลิก
         $customers = User::where('is_admin', '!=', 1)
         ->withCount([
             'timereservs as successful_count' => function ($query) {
                 $query->where('statusdetail', 'จองสำเร็จ');
             },
             'timereservs as cancelled_count' => function ($query) {
                    $query->withTrashed()->whereIn('statusdetail', ['ยกเลิกการจองจากผู้ใช้']);
                }
            ])->get();

            $totalUsers = User::where('is_admin', '!=', 1)->count();
           
       // ดึงข้อมูลการชำระเงินที่จ่ายเข้ามา
    $payments = Payment::where('status', 'ชำระเงินเเล้ว')
    ->join('timereservs', 'payments.reservs_id', '=', 'timereservs.reservs_id')
    ->select('payments.amount', 'payments.payment_date', 'timereservs.statusdetail', 'timereservs.deleted_at')
    ->get();
    
    // คำนวณค่ามัดจำทั้งหมด
    $totalDeposit = $payments->sum(function ($payment) {
        return ($payment->statusdetail === 'ยกเลิกการจอง') ? ($payment->amount - 300) : $payment->amount;
    });
    
     // คำนวณค่ามัดจำที่ต้องคืน
     $refundAmount = $payments->sum(function ($payment) {
        return ($payment->statusdetail === 'ยกเลิกการจอง') ? -300 : 0;
    });

    // จัดรูปแบบข้อมูลสำหรับ FullCalendar
    $paymentEvents = [];
    foreach ($payments as $payment) {
        if ($payment->statusdetail === 'ยกเลิกการจอง' && $payment->deleted_at) {
            // ถ้าการจองถูกยกเลิกหลังจากชำระเงิน ให้แสดงเป็น -300 (สีแดง)
            $paymentEvents[] = [
                'title' => '-300',
                'start' => $payment->deleted_at,
                'color' => 'red',
                'textColor' => 'white',
        ];
        } else {
            // ถ้าชำระเงินปกติ ให้แสดงเป็น +300 (สีเขียว)
            $paymentEvents[] = [
                'title' => '+300',
                'start' => $payment->payment_date,
                'color' => 'green',
                'textColor' => 'white',
            ];
        }
    }


    // คำนวณจำนวนครั้งที่ใช้โค้ดโปรโมชั่นทั้งหมด
    $totalPromotionUsage = UseCode::count();

     // ดึงข้อมูลโปรโมชั่นที่มีการใช้ และเรียงจากจำนวนการใช้มากไปน้อย
     $usedPromotions = UseCode::select('promotion_id', \DB::raw('COUNT(*) as usage_count'))
     ->groupBy('promotion_id')
     ->orderByDesc('usage_count')
     ->get();

 // นำ promotion_id ไปดึงรายละเอียดของโปรโมชั่นจากตาราง promotions
 $usedPromotions = $usedPromotions->map(function ($promo) {
     $promotion = Promotion::find($promo->promotion_id);
     return [
         'promotion_name' => $promotion->promotion_name,
         'promotion_code' => $promotion->promotion_code,
         'discount_type' => $promotion->discount_type,
         'discount_value' => $promotion->discount_value,
         'usage_count' => $promo->usage_count
     ];
 });

  // ดึงลายเล็บที่ถูกจองสำเร็จ และเลือกมาแค่ 1 รูปต่อการจอง
  $popularNailDesigns = DetailTimereserv::whereHas('timereserv', function ($query) {
    $query->where('statusdetail', 'จองสำเร็จ');
})
->select('nail', \DB::raw('COUNT(DISTINCT reservs_id) as total_reservations'))
->whereNotNull('nail')
->groupBy('nail')
->orderByDesc('total_reservations')
->with('nailDesign') // โหลดข้อมูลลายเล็บที่เกี่ยวข้อง
->get();
    

         return view('dashboard', compact('totalReservations','successfulBookings','cancelledBookings', 'customers','totalDeposit'
         , 'paymentEvents', 'ownerCancelledBookings', 'totalUsers','refundAmount', 'expiredPayments','usedPromotions','totalPromotionUsage',
         'popularNailDesigns'));
    }

    public function getDepositData(Request $request)
{
    $month = $request->input('month', now()->month);
    $year = $request->input('year', now()->year);

    // ดึงข้อมูลค่ามัดจำ และค่าที่คืนค่ามัดจำ ตามเดือนและปีที่เลือก
    $payments = Payment::where('status', 'ชำระเงินเเล้ว')
        ->whereMonth('payment_date', $month)
        ->whereYear('payment_date', $year)
        ->join('timereservs', 'payments.reservs_id', '=', 'timereservs.reservs_id')
        ->select('payments.amount', 'timereservs.statusdetail')
        ->get();

    $totalDeposit = $payments->sum(fn($p) => ($p->statusdetail === 'ยกเลิกการจอง') ? ($p->amount - 300) : $p->amount);
    $refundAmount = $payments->sum(fn($p) => ($p->statusdetail === 'ยกเลิกการจอง') ? -300 : 0);

    return response()->json([
        'totalDeposit' => $totalDeposit,
        'refundAmount' => $refundAmount,
    ]);
}




}
