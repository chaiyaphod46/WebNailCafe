            
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nailcafe</title>
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">


</head>
<body>

@section('content')
<section class="pb-4">
  <div class="border rounded-5"> 
    <section class="w-100 p-4 p-xl-5" style="background-color: #F9C6B0 ; border-radius: .5rem .5rem 0 0;">
      <div class="row d-flex justify-content-center">
        <div class="col-12">
          <div class="card" style="border-radius: 1rem;">
            <div class="row g-0">
              <div class="col-md-6 col-lg-5 d-none d-md-block ">
                <img src="imag\nailcafe1.jpg" width="100%" height="100%" alt="login form" class="img-fluid " style="border-radius: 1rem 0 0 1rem;">
              </div>
              <div class="col-md-6 col-lg-7 d-flex align-items-center " style="background-color: #FEFBFA ">
                <div class="card-body p-4 p-lg-5 text-black">

                  <form method="POST" action="{{ route('login') }}">

                    <div class="d-flex align-items-center mb-3 pb-1">
                      <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                      <span class="h1 fw-bold mb-0">NailCafe</span>
                    </div>

                    <div class="form-outline mb-4">
                       @csrf
                      <label class="form-label" for="email">{{ __('อีเมล') }}</label>
                      <input id="email" type="email"  class="form-control form-control-lg" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                       @error('email')
                        <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                        </span>
                       @enderror
                    </div>

                    <div class="form-outline mb-4">
                      <label class="form-label" for="password">{{ __('รหัสผ่าน') }}</label>
                      <input type="password" id="password" class="form-control form-control-lg" name="password" required autocomplete="current-password">                    
                     @error('password')
                     <span class="invalid-feedback" role="alert">
                       <strong>{{ $message }}</strong>
                     </span>
                     @enderror
                    </div>

                    <div class="pt-1 mb-4">
                      <button class="btn btn-dark btn-lg btn-block" type="submit">{{ __('เข้าสู่ระบบ') }}</button>
                      
                    </div>
                    <p class="mb-5 pb-lg-2" style="color: #393f81;">หากคุณยังไม่ลงทะเบียน <a href="{{url('/register')}}" style="color: #393f81;">ลงทะเบียน</a></p>
                    
                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
  </div>
</section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script> 
</body>
</html>




