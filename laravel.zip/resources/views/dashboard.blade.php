<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NailCafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminstyle.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css">
</head>
<body>

<!-- jQuery และ FullCalendar JS -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>

<script>
    $(document).ready(function () {
        $('#dashboardCalendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay'
            },
            defaultView: 'month',
            events: @json($paymentEvents),
            selectable: false, // ไม่ให้เลือกวันที่
            allDaySlot: false,
            slotLabelFormat: 'H:mm',
            timeFormat: 'H:mm',
            minTime: '11:00', 
            maxTime: '20:00',
            monthNames: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'],
            monthNamesShort: ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'],
            dayNames: ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'],
            dayNamesShort: ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'],
        });
    });
</script>

    <main class="d-flex flex-nowrap">
        @include('navbar')

        <div class="p-3 container-fluid">
            <div class="p-2 mb-1 rounded-3 shadow-sm" style="background-color: rgb(252, 229, 220);">
                <center><h5 class="fw-bold">เเดชบอด</h5></center>
            </div>
            <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                        
                    </div>

                    <!-- เเถวเเรก------------------------------------------->
                    <div class="row">

                        <!-- จำนวนรายการจอง -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                รายการจองทั้งหมด</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    {{ $totalReservations }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                รายการจองสำเร็จ</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    {{ $successfulBookings }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->

                    </div>

                    <!-- ------------------------------------------------------------->

                    <!-- เเถวสอง ------------------------------------------->

                    <div class="row">

                    <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                        รายการถูกยกเลิก</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                        {{ $cancelledBookings }} รายการ
                        </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- จำนวนรายการจอง -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                รายการหมดเวลาชำระเงิน</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $expiredPayments }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                รายการยกเลิกจากเจ้าของร้าน</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $ownerCancelledBookings }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                รายการยกเลิกการจองจากลูกค้า</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $customers->sum('cancelled_count') }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            
                        </div>
                    </div>

                    <!-- -------------------------------------------------------------->

                    <!--เเถวสาม -------------------------------------------------------------->

                    <div class="row">

<!-- Earnings (Monthly) Card Example -->
<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                        ค่ามัดจำทั้งหมด</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            {{ $totalDeposit }} บาท
                        </div>
                </div>
                <div class="col-auto">
                <i class="fas fa-calendar fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Earnings (Monthly) Card Example -->
<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                        คืนค่ามัดจำ</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                        {{ abs($refundAmount)}} บาท
                        </div>
                </div>
                <div class="col-auto">
                <i class="fas fa-calendar fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</div>


</div>

<!-- -------------------------------------------------------------->

                    <!-- เเสดงปฏิทิน ----------------------------->

                    <div class="row">

                        <!-- รายรับรายจ่าย -->
                        <div class="col-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">ปฏิทินรายรับจากค่ามัดจำ</h6>
                                    
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="dashboardCalendar"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                        <!-- -------------------------------------------------------------->


                        <div class="row">

<!-- กราฟรายรับค่ามัดจำ -->
<div class="col-xl-8 col-lg-7">
    <div class="card shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">รายรับรายจ่าย</h6>
            <div class="d-flex">
                <div class="mr-2">
                    <select id="monthSelect" class="form-control" style="width: 150px;">
                        @php
                            $thaiMonths = [
                                1 => 'มกราคม', 2 => 'กุมภาพันธ์', 3 => 'มีนาคม', 4 => 'เมษายน',
                                5 => 'พฤษภาคม', 6 => 'มิถุนายน', 7 => 'กรกฎาคม', 8 => 'สิงหาคม',
                                9 => 'กันยายน', 10 => 'ตุลาคม', 11 => 'พฤศจิกายน', 12 => 'ธันวาคม'
                            ];
                        @endphp
                        @for ($i = 1; $i <= 12; $i++)
                            <option value="{{ $i }}" {{ $i == now()->month ? 'selected' : '' }}>
                                {{ $thaiMonths[$i] }}
                            </option>
                        @endfor
                    </select>
                </div>

                <div>
                    <input type="number" id="yearSelect" class="form-control" style="width: 120px;"
                        value="{{ now()->year }}" min="1900" max="2100">
                </div>
            </div>
        </div>
        <!-- Card Body -->
        <div class="card-body">
            <div class="chart-area">
                <canvas id="myAreaChart"></canvas>
            </div>
        </div>
    </div>
</div>


<!--  -->
<div class="col-xl-4 col-lg-5">
    <div class="card shadow mb-4">
        <!-- Card Header -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">ลายเล็บที่ลูกค้าเลือกจองมากที่สุด</h6>
        </div>
        
        <!-- Card Body (เพิ่ม Scroll) -->
        <div class="card-body" style="max-height: 400px; overflow-y: auto;">
            @foreach ($popularNailDesigns as $nail)
                <div class="card mb-3 shadow-sm border-0">
                    <div class="card-body p-2 text-center">
                        <!-- รูปภาพลายเล็บ -->
                        <img src="{{ asset('naildesingimage/' . $nail->nailDesign->image) }}" 
                             alt="ลายเล็บ" class="img-fluid rounded" style="max-width: 100%; height: auto;">
                        
                        <!-- จำนวนครั้งที่ถูกจอง -->
                        <div class="bg-light mt-2 py-1 rounded">
                            <p class="mb-0 text-secondary">เลือกจากลูกค้า <strong>{{ $nail->total_reservations }}</strong> ครั้ง</p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>



</div>



                        <!-- เเถวสี่-------------------------------------------------------------->
                        <div class="row">

                        <!-- จำนวนรายการจอง -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                ผู้ใช้ในระบบทั้งหมด</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $totalUsers }} คน
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                รายการจองสำเร็จ</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    {{ $successfulBookings }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                รายการยกเลิกการจองจากลูกค้า</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $customers->sum('cancelled_count') }} รายการ
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                xxxxxxxxxxxxxxxxxx</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                xxxxxxxxxxxxxxx
                                                </div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                        
                <!-- ------------------------------------------------------------------->

                    <div class="row">
                        <!-- รายรับรายจ่าย -->
                        <div class="col-12">
    <div class="card shadow mb-4">
        <!-- Card Header -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">ข้อมูลลูกค้า</h6>  
        </div>
        <!-- Card Body -->
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>ชื่อ</th>
                            <th>อีเมล</th>
                            <th>เบอร์โทร</th>
                            <th>จองสำเร็จ</th>
                            <th>ยกเลิกการจอง</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $index => $customer)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $customer->name }}</td>
                                <td>{{ $customer->email }}</td>
                                <td>{{ $customer->phon }}</td>
                                <td>{{ $customer->successful_count }}</td>
                                <td>{{ $customer->cancelled_count }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<div class="row">

<!-- จำนวนใช้โปรโมชัน-->
<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                        จำนวนการใช้โปรโมชันทั้งหมด
                    </div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                        {{ $totalPromotionUsage }} ครั้ง
                    </div>
                </div>
                <div class="col-auto">
                    <i class="fas fa-calendar fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</div>


</div>


<!----------------------------------------------------->

<div class="row">
    <div class="col-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">โปรโมชันที่ลูกค้าเลือกใช้มากที่สุด</h6>
            </div>
            <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ชื่อโปรโมชัน</th>
                        <th>รหัสโปรโมชัน</th>
                        <th>จำนวนครั้งที่ใช้</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($usedPromotions as $promotion)
                        <tr>
                            <td>{{ $promotion['promotion_name'] }}</td>
                            <td>{{ $promotion['promotion_code'] }}</td>
                            <td>{{ $promotion['usage_count'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
        </div>
    </div>
</div>
       






        </div>
    </main>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    let ctx = document.getElementById("myAreaChart").getContext("2d");

    let myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["รายรับค่ามัดจำ", "ค่าที่คืนค่ามัดจำ"],
            datasets: [{
                label: "จำนวนเงิน (บาท)",
                data: [0, 0],
                backgroundColor: function(context) {
                    let index = context.dataIndex;
                    return index === 1 ? "#e74a3b" : "#4e73df";
                },
                barThickness: 40
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    function updateChart(month, year) {
        fetch(`/dashboard/deposit-data?month=${month}&year=${year}`)
            .then(response => response.json())
            .then(data => {
                myChart.data.datasets[0].data = [data.totalDeposit, Math.abs(data.refundAmount)];
                myChart.update();
            });
    }

    let monthSelect = document.getElementById("monthSelect");
    let yearInput = document.getElementById("yearSelect");

    function handleFilterChange() {
        let selectedYear = parseInt(yearInput.value, 10);
        if (selectedYear < 1900 || selectedYear > 2100) {
            alert("กรุณาเลือกปีระหว่าง 1900 - 2100");
            return;
        }
        updateChart(monthSelect.value, selectedYear);
    }

    monthSelect.addEventListener("change", handleFilterChange);
    yearInput.addEventListener("input", handleFilterChange);

    updateChart(monthSelect.value, yearInput.value);
});
</script>

   

</body>
</html>
